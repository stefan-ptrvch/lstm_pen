"""
Trying to make an LSTM which can tell the difference between a couple different
letters.
"""

from __future__ import print_function

import argparse
import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense, LSTM
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import confusion_matrix, f1_score
from tensorflow.python.lib.io import file_io
from pandas.compat import StringIO


# Set seed for reproducibility
np.random.seed(7)

# Load data
f = file_io.FileIO("gs://lstm-pencil-data/dataset_digits_5ms", mode='r' )
df = pd.read_csv(StringIO(f.read()))
logs_path = "gs://lstm-pencil-data/logs"

### FOR TESTING, DROP SOME SAMPLES ###
df = df[(df["digit"] == 7) | (df["digit"] == 8) | (df["digit"] == 9)]
### FOR TESTING, DROP SOME SAMPLES ###

# Get sequence with most samples (probably an O)
NUM_STEPS = df["sample"].value_counts().max()
NUM_FEATURES = 6
NUM_CLASSES = df["digit"].unique().size

# Map letters to numbers inside dataframe (prolly not needed for digits)
mapping = {
        'A': 0,
        'B': 1,
        'C': 2,
        'D': 3,
        'E': 4,
        'F': 5,
        'G': 6,
        'H': 7,
        'I': 8,
        'J': 9,
        'K': 10,
        'L': 11,
        'M': 12,
        'N': 13,
        'O': 14,
        'P': 15,
        'Q': 16,
        'R': 17,
        'S': 18,
        'T': 19,
        'U': 20,
        'V': 21,
        'W': 22,
        'X': 23,
        'Y': 24,
        'Z': 25
        }
#  df.replace({"letter": mapping}, inplace=True)

# Dummy matrix for zero-padding
dummy = np.zeros((NUM_STEPS, NUM_FEATURES + 1))

# Other dummy for stacking
stack_dummy = np.zeros((1, NUM_FEATURES + 1))

# Go through all sequences and pad with zeros
for index in df["sample"].unique():
    sequence = df[df["sample"] == index]
    num_samples = sequence.shape[0]
    dummy[:num_samples, :NUM_FEATURES] = sequence[["xa", "ya", "za", "xg",
                                                   "yg", "zg"]].values
    dummy[:, NUM_FEATURES] = sequence["digit"].unique()[0]
    stack_dummy = np.vstack((stack_dummy, dummy))

    # Fill dummy with zeros again
    dummy = np.zeros((NUM_STEPS, NUM_FEATURES + 1))

# Drop first row of stack dummy
stack_dummy = stack_dummy[1:]

# Get feature matrix and reshape it into 3D array
features = stack_dummy[:, :NUM_FEATURES]
num_samples = features.shape[0]//NUM_STEPS
features = features.reshape((num_samples, NUM_STEPS, NUM_FEATURES))

# Make a label vector and do one-hot encoding on it
labels = stack_dummy[:, NUM_FEATURES][::NUM_STEPS]
encoder = OneHotEncoder(sparse=False)
labels = encoder.fit_transform(labels.reshape((num_samples, 1)))

# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(features, labels)

# Build LSTM model
model = Sequential()
model.add(LSTM(900, dropout=0.2, input_shape=(NUM_STEPS, NUM_FEATURES)))
model.add(Dense(NUM_CLASSES, activation="softmax"))
model.compile(loss="categorical_crossentropy", optimizer="adam",
              metrics=["accuracy"])
print(model.summary())

NUM_EPOCHS = 80
#  NUM_EPOCHS = 40
history = model.fit(X_train, y_train, epochs=NUM_EPOCHS, batch_size=16)
#  history = model.fit(features, labels, validation_data=[X_test, y_test],
                    #  epochs=NUM_EPOCHS, batch_size=16)

# Evaluate model
scores = model.evaluate(X_test, y_test, verbose=0)
print("Accuracy: %.2f" % (scores[1]*100))

# Works great!

# Compute confusion matrix
y_pred = model.predict(X_test)
cnf_matrix = confusion_matrix(y_test.argmax(1), y_pred.argmax(1))


# Calculate the F1 score
print("F1 score per label: " + ', '.join(map(
    str, np.around(f1_score(
        y_test.argmax(1),
        y_pred.argmax(1),
        average=None),
        2))))
print("Global F1 score: %.2f" % f1_score(y_test.argmax(1), y_pred.argmax(1),
    average="micro"))
